from flask import Blueprint, request, jsonify
from .monad_rpc import get_balance

mcp_routes = Blueprint("mcp", __name__)

@mcp_routes.route("/balance", methods=["POST"])
def balance():
    data = request.get_json()
    address = data.get("address")
    if not address:
        return jsonify({"error": "No address provided"}), 400
    try:
        balance = get_balance(address)
        return jsonify({"address": address, "balance": balance})
    except Exception as e:
        return jsonify({"error": str(e)}), 500