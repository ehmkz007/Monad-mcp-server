from web3 import Web3

# Replace with the actual RPC of Monad testnet
RPC_URL = "https://rpc.testnet.monad.xyz"

web3 = Web3(Web3.HTTPProvider(RPC_URL))

def get_balance(address):
    balance_wei = web3.eth.get_balance(address)
    return web3.from_wei(balance_wei, "ether")