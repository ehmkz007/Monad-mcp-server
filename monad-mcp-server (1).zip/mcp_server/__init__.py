from flask import Flask
from .routes import mcp_routes

def create_app():
    app = Flask(__name__)
    app.register_blueprint(mcp_routes)
    return app